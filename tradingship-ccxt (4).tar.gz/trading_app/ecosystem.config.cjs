/**
 * PM2 Ecosystem Config — TradingShip
 *
 * NOTE: `cwd` is auto-set by setup.sh — do not edit manually.
 *
 * Start:   pm2 start ecosystem.config.cjs
 * Reload:  pm2 reload tradingship
 * Logs:    pm2 logs tradingship
 * Monitor: pm2 monit
 */
module.exports = {
  apps: [
    {
      name: "tradingship",
      script: "./artifacts/api-server/dist/index.mjs",

      // setup.sh automatically sets this to the correct absolute path
      cwd: "/root/tradingship",

      // Node.js flags
      node_args: "--enable-source-maps",

      // Single process (no clustering — WS state must stay in one process)
      instances: 1,
      exec_mode: "fork",

      // Auto-restart on crash
      autorestart: true,
      watch: false,

      // Restart if memory exceeds 1.5 GB
      max_memory_restart: "1500M",

      // Cooldown between restarts
      restart_delay: 3000,
      max_restarts: 10,
      min_uptime: "10s",

      // Load env from .env file in cwd
      env_file: ".env",

      // Log files
      out_file:        "/var/log/tradingship/out.log",
      error_file:      "/var/log/tradingship/error.log",
      merge_logs:      true,
      log_date_format: "YYYY-MM-DD HH:mm:ss Z",
    },
  ],
};
