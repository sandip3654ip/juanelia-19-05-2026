/**
 * CCXT Pro unified spot adapter
 *
 * Replaces the four hand-written WebSocket adapters
 * (BinanceSpotAdapter / BybitSpotAdapter / KucoinSpotAdapter / BitgetSpotAdapter).
 *
 * One class — instantiated once per exchange in spot-scanner/index.ts:
 *   new CcxtSpotAdapter('binance')
 *   new CcxtSpotAdapter('bybit')
 *   new CcxtSpotAdapter('kucoin')
 *   new CcxtSpotAdapter('bitget')
 *
 * CCXT Pro handles internally (nothing to code):
 *   ✓ WebSocket connect / reconnect / keepalive / ping-pong
 *   ✓ Exchange-specific message formats
 *   ✓ Rate limiting
 *   ✓ Heartbeat
 *   ✓ NAT/TCP dead-connection detection
 *
 * Public interface is identical to the old adapters:
 *   quotes    — Map<string, SpotQuote>  (keyed by canonical coin, e.g. "BTC")
 *   feeMap    — Map<string, {maker,taker}>  (Bitget only; empty for others)
 *   dataSource — always "ws"
 *   start() / stop()
 */

import ccxt from "ccxt";
import { logger } from "../../logger.js";
import type { SpotQuote } from "../types.js";

// ── Constants ──────────────────────────────────────────────────────────────

const STABLES = new Set(["USDT", "USDC", "BUSD"]);
const RECONNECT_DELAY_MS = 3_000;

// Bitget fee endpoint (same as old adapter)
const BITGET_FEES_URL = "https://api.bitget.com/api/v2/spot/public/symbols";

// ── Helpers ────────────────────────────────────────────────────────────────

/**
 * Convert a CCXT symbol ("BTC/USDT" or "BTC/USDT:USDT") to the canonical
 * coin name used as a quotes-map key ("BTC").
 * Returns null for non-stable-quote pairs.
 */
function stripQuote(ccxtSymbol: string): string | null {
  const slash = ccxtSymbol.indexOf("/");
  if (slash === -1) return null;
  const base  = ccxtSymbol.slice(0, slash).toUpperCase();
  const rest  = ccxtSymbol.slice(slash + 1).toUpperCase();
  const quote = rest.split(":")[0]; // strip ":USDT" settlement suffix if present
  if (!STABLES.has(quote)) return null;
  return base;
}

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ── Adapter ────────────────────────────────────────────────────────────────

export class CcxtSpotAdapter {
  /** Live bid/ask quotes, keyed by canonical coin name e.g. "BTC". */
  readonly quotes = new Map<string, SpotQuote>();

  /**
   * Per-symbol fees for Bitget (same interface as old BitgetSpotAdapter.feeMap).
   * Empty for all other exchanges — feeGetter in index.ts falls back to
   * getTradingFees() static rates when this map has no entry.
   */
  readonly feeMap = new Map<string, { maker: number; taker: number }>();

  /** Always "ws" — CCXT Pro uses WebSocket streams. */
  get dataSource(): "ws" | "rest" { return "ws"; }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private ex: any = null;
  private stopped  = false;
  private symbols: string[] = [];

  constructor(private readonly exchangeId: "binance" | "bybit" | "kucoin" | "bitget") {}

  // ── Public API ─────────────────────────────────────────────────────────────

  start(): void {
    this.stopped = false;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const ExClass = (ccxt as any).pro[this.exchangeId];
    if (!ExClass) {
      logger.error({ exchange: this.exchangeId }, "ccxt.pro does not have this exchange");
      return;
    }
    this.ex = new ExClass({
      enableRateLimit: true,
      newUpdates:      true,          // resolve watchTickers on EVERY update
      options:         { defaultType: "spot" },
    });
    void this.run();
  }

  stop(): void {
    this.stopped = true;
    void this.ex?.close().catch(() => {});
  }

  // ── Internal ───────────────────────────────────────────────────────────────

  private async run(): Promise<void> {
    // ── 1. For Bitget: fetch per-symbol fees via REST (same as old adapter) ──
    if (this.exchangeId === "bitget") {
      void this.fetchBitgetFees(); // fire-and-forget; non-blocking
    }

    // ── 2. Load markets — retry forever until success ─────────────────────
    while (!this.stopped) {
      try {
        await this.ex.loadMarkets();
        this.symbols = Object.values(
          this.ex.markets as Record<string, {
            spot:   boolean;
            active: boolean;
            quote:  string;
            symbol: string;
          }>,
        )
          .filter(m => m.spot && m.active && STABLES.has(m.quote ?? ""))
          .map(m => m.symbol);

        logger.info(
          { exchange: this.exchangeId, count: this.symbols.length },
          "ccxt spot markets loaded",
        );
        break;
      } catch (err) {
        logger.warn(
          { exchange: this.exchangeId, err: String(err) },
          "ccxt loadMarkets failed — retrying in 3s",
        );
        await sleep(RECONNECT_DELAY_MS);
      }
    }

    if (this.stopped || this.symbols.length === 0) return;

    // ── 3. Watch loop ───────────────────────────────────────────────────────
    //
    // Strategy per exchange (all resolved empirically on Replit's shared IP):
    //
    //   Binance  → watchTickers() with NO symbols → !ticker@arr broadcast
    //              (individual streams get 1008 policy violation on cloud IPs)
    //   KuCoin   → watchTickers() with NO symbols → /market/ticker:all broadcast
    //              (comma-sep topic with 900+ symbols gives BadRequest)
    //   Bybit    → watchTickers() with NO symbols → tickers.spot broadcast
    //              (per-symbol chunks produce no data on Replit IP)
    //   Bitget   → watchTickers(chunk) in groups of 100 symbols
    //              (no all-market broadcast; per-symbol chunks work fine)
    //
    // CCXT Pro manages the WebSocket lifecycle and reconnects automatically.

    // Per-exchange WebSocket strategy (determined empirically on Replit shared IP):
    //
    //   Binance  → watchTickers() no-args  → !ticker@arr broadcast (IP blocked on individual)
    //   KuCoin   → watchTickers() no-args  → /market/ticker:all broadcast (900+ sym topic fails)
    //   Bybit    → watchBidsAsks(chunk)    → orderbook best bid/ask stream (ticker stream has no bid/ask)
    //   Bitget   → watchTickers(chunk)     → per-symbol ticker chunks of 100

    if (this.exchangeId === "binance" || this.exchangeId === "kucoin") {
      await this.watchAllMarketStream();
    } else if (this.exchangeId === "bybit") {
      await this.watchBybitBidsAsks();
    } else {
      await this.watchChunked();
    }

    logger.info({ exchange: this.exchangeId }, "ccxt spot adapter stopped");
  }

  // ── Binance / KuCoin: all-market broadcast stream ─────────────────────────
  //
  // Calling watchTickers() with NO symbols makes CCXT use the exchange's
  // native all-market broadcast:
  //   Binance  → !ticker@arr  (avoids individual stream IP blocks on cloud)
  //   KuCoin   → /market/ticker:all  (avoids BadRequest from 900+ symbol topic)

  private async watchAllMarketStream(): Promise<void> {
    while (!this.stopped) {
      try {
        const tickers = await this.ex.watchTickers() as Record<
          string,
          { bid: number | undefined; ask: number | undefined }
        >;
        const now = Date.now();
        for (const [sym, ticker] of Object.entries(tickers)) {
          const base = stripQuote(sym);
          if (!base) continue;
          const bid = typeof ticker.bid === "number" ? ticker.bid : 0;
          const ask = typeof ticker.ask === "number" ? ticker.ask : 0;
          if (bid > 0 && ask > 0) {
            this.quotes.set(base, { bid, ask, receivedAt: now });
          }
        }
      } catch (err) {
        if (this.stopped) break;
        logger.warn(
          { exchange: this.exchangeId, err: String(err) },
          "ccxt watchTickers (all-market) error — retrying",
        );
        await sleep(RECONNECT_DELAY_MS);
      }
    }
  }

  // ── Bybit: watchBidsAsks chunked ──────────────────────────────────────────
  //
  // Bybit's ticker stream does NOT include bid/ask prices (only last price).
  // watchBidsAsks() uses the orderbook best-bid/ask stream which DOES have them.
  // Chunked to stay within Bybit's subscription limits.

  private async watchBybitBidsAsks(): Promise<void> {
    const CHUNK_SIZE = 50;
    const chunks: string[][] = [];
    for (let i = 0; i < this.symbols.length; i += CHUNK_SIZE) {
      chunks.push(this.symbols.slice(i, i + CHUNK_SIZE));
    }
    logger.info(
      { exchange: "bybit", chunks: chunks.length, symbolsPerChunk: CHUNK_SIZE },
      "ccxt spot bybit starting watchBidsAsks chunks",
    );
    await Promise.all(chunks.map(chunk => this.watchBybitChunkLoop(chunk)));
  }

  private async watchBybitChunkLoop(chunk: string[]): Promise<void> {
    while (!this.stopped) {
      try {
        const tickers = await this.ex.watchBidsAsks(chunk) as Record<
          string,
          { bid: number | undefined; ask: number | undefined }
        >;
        const now = Date.now();
        for (const [sym, ticker] of Object.entries(tickers)) {
          const base = stripQuote(sym);
          if (!base) continue;
          const bid = typeof ticker.bid === "number" ? ticker.bid : 0;
          const ask = typeof ticker.ask === "number" ? ticker.ask : 0;
          if (bid > 0 && ask > 0) {
            this.quotes.set(base, { bid, ask, receivedAt: now });
          }
        }
      } catch (err) {
        if (this.stopped) break;
        logger.warn(
          { exchange: "bybit", err: String(err) },
          "ccxt bybit watchBidsAsks error — retrying",
        );
        await sleep(RECONNECT_DELAY_MS);
      }
    }
  }

  // ── Bitget: chunked symbol-specific subscriptions ─────────────────────────
  //
  // Bitget has no all-market broadcast, so we watch in parallel chunks.

  private async watchChunked(): Promise<void> {
    const CHUNK_SIZE = 100;
    const chunks: string[][] = [];
    for (let i = 0; i < this.symbols.length; i += CHUNK_SIZE) {
      chunks.push(this.symbols.slice(i, i + CHUNK_SIZE));
    }
    logger.info(
      { exchange: this.exchangeId, chunks: chunks.length, symbolsPerChunk: CHUNK_SIZE },
      "ccxt spot starting chunked watchTickers",
    );

    // Run all chunk loops concurrently; finish when stopped
    await Promise.all(chunks.map(chunk => this.watchChunkLoop(chunk)));
  }

  private async watchChunkLoop(chunk: string[]): Promise<void> {
    while (!this.stopped) {
      try {
        const tickers = await this.ex.watchTickers(chunk) as Record<
          string,
          { bid: number | undefined; ask: number | undefined }
        >;
        const now = Date.now();
        for (const [sym, ticker] of Object.entries(tickers)) {
          const base = stripQuote(sym);
          if (!base) continue;
          const bid = typeof ticker.bid === "number" ? ticker.bid : 0;
          const ask = typeof ticker.ask === "number" ? ticker.ask : 0;
          if (bid > 0 && ask > 0) {
            this.quotes.set(base, { bid, ask, receivedAt: now });
          }
        }
      } catch (err) {
        if (this.stopped) break;
        logger.warn(
          { exchange: this.exchangeId, err: String(err) },
          "ccxt watchTickers (chunk) error — retrying",
        );
        await sleep(RECONNECT_DELAY_MS);
      }
    }
  }

  // ── Bitget: per-symbol fee fetch (identical logic to old BitgetSpotAdapter) ─

  private async fetchBitgetFees(): Promise<void> {
    try {
      const res = await fetch(BITGET_FEES_URL, {
        signal: AbortSignal.timeout(15_000),
      });
      if (!res.ok) throw new Error(`symbols HTTP ${res.status}`);
      const body = (await res.json()) as {
        data: Array<{ symbol: string; makerFeeRate: string; takerFeeRate: string }>;
      };

      for (const item of body.data) {
        const base = item.symbol.toUpperCase().replace(/USDT$|USDC$|BUSD$/, "");
        if (!base) continue;
        const maker = parseFloat(item.makerFeeRate);
        const taker = parseFloat(item.takerFeeRate);
        if (!isFinite(maker) || !isFinite(taker)) continue;
        this.feeMap.set(base, { maker, taker });
      }
      logger.info({ count: this.feeMap.size }, "bitget spot fees loaded (ccxt adapter)");
    } catch (err) {
      logger.warn(
        { err: String(err) },
        "bitget spot fee fetch failed (ccxt adapter) — falling back to static rates",
      );
    }
  }
}
